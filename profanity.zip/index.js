const express = require('express');
const app = express();
app.listen( 5434 ,() => console.log("listening at 5434"));
app.post('/index',function(req1,res){
	console.log("hello There");
});