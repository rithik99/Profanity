function okk(){
	alert("submitting");
	document.getElementById("frm1").submit();

}